void record() {
    char plname[20];
    FILE *info = fopen("record.txt", "a+");
    system("cls");
    printf("Enter your name\n");
    scanf("%s", plname);

    fprintf(info, "Player Name : %s\n", plname);
    fprintf(info, "Score : %d\n", Scoreonly());
    fclose(info);
}
